import React from 'react';

function Vegitables(props) {
    return (
        <div>
            <h2>Vegitables</h2>
        </div>
    );
}

export default Vegitables;